import os
import Defs as df




accounts = [["v.victorgabriel2014@gmail.com","Victor","123456"]]

def conBdUser(metodo):
    users = open("bd_users.txt",metodo)
    if metodo == "a":
        



def Login(Login,Senha):
    for user in accounts:
        if Login == user[0] and Senha == user[2]:
            print('Usuário localizado')
            return user
    return False

def newUser():
    login = None
    nome = None
    senha = None

    while login == None or nome == None or senha == None:
        df.Cls()
        df.Div()
        print('  TELA DE CADASTRO')
        
        print('  Login: ',login)
        print('  Nome: ',nome)
        print('  Senha: ',senha)

        df.Div()
      
        if login == None:
            login = str(input('Digite o Login: '))

        elif nome == None and login != None:
            nome = str(input('Digite o Nome do novo usuário: '))
        elif senha == None and nome != None:
            while True:
                senha1 = str(input('Digite a senha do novo usuário: '))
                df.Cls()
                df.Div()
                print('  TELA DE CADASTRO')
                
                print('  Login: ',login)
                print('  Nome: ',nome)
                print('  Senha: ',senha)
                df.Div()
                senha2 = str(input('Confirme a senha: '))

                if senha1 == senha2:
                    senha = senha1
                    break
                else:
                    print('As senhas estão divergentes!')

    df.Cls()
    df.Div()
    print('  TELA DE CADASTRO')
    
    print('  Login: ',login)
    print('  Nome: ',nome)
    print('  Senha: ',senha)
    df.Div()

    confirm = int(input('Confirma as informações acima? 1-Sim | 2-Não:\n'))
    if confirm == 1:
        accounts.append([login,nome,senha])
        return True
    elif confirm == 2:
        return False
        
def editUser():
    df.Cls()
    df.Div()
    print("  TELA DE EDIÇÃO")
    print("  Digite o login do usuário que quer editar")
    df.Div()
    

